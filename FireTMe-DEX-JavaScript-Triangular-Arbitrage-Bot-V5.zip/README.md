#JavaScript-DEX-Triangular-Arbitrage-Bot-v5 
feel free to fork and improve or whatever. 
if you fork and modify please give credit
This is a tutorial to help run the JavaScript DEX Triangular Arbitrage Bot v5 (javascript version).

Let’s get started.

Part 1. Main software installations.

Extract the zip file anywhere you like that easy for you to find.

Part 2. Editing the settings.

Open the bots main folder and find "config.js" file and open it with a text-editor:

1.Set your public address and private key or your wallet seed if you have a wallet that does not give you the private key

2.Set the Network  1 = ETH , 56 = BNB , 137 = POLYGON

3.Save config.js

4.Open run.html in any web-browser


